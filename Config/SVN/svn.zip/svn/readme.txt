Simply extract the archive into a newly created directory %B\Config\SVN 
and run the svn_install.edt macro. 

Note that this has been tested with TortoiseSVN, and it must be installed 
for the SVN macro to work.
