___________________________________________________________

 Zoom your documents in and out [for WinEdt 9]

===========================================================

 by Karl Koeller
 E-mail: karlkoeller@gmail.com

 http://www.winedt.org/

___________________________________________________________


This package provides some useful menu items (and shortcuts) for
managing the zoom in your documents.

---------------------------
 INSTALLATION
---------------------------

Open the macro file "Install.edt" in WinEdt, and execute it by
choosing "Macros" menu > "Execute Current Macro".

---------------------------
 UNINSTALLATION
---------------------------

Open the macro file "Uninstall.edt" in WinEdt (also available in
%b\Uninstall\DocZoom folder), and execute it by choosing "Macros"
menu > "Execute Current Macro".

---------------------------
 USAGE
---------------------------

A submenu "Zoom" containing zooming commands is added to the menu
"View". You can also use the shortcut Ctrl+U to zoom in and the
shortcut Ctrl+D to zoom out. The zooming range is 8<->20.

When you act on the zoom, info on the size of the used font is
displayed in the status bar. Clicking on it will restore the
default value.
